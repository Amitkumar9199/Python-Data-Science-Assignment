import setuptools
setuptools.setup(
 name='objectdetectionmodelamit',
 version='0.1',
 author="Amit Kumar",
 author_email="ramanujaamit@gmail.com",
 description="This package helps in object detection",
 packages=setuptools.find_packages(),
 classifiers=[
 "Programming Language :: Python :: 3",
 "License :: OSI Approved :: MIT License",
 "Operating System :: OS Independent",
 ],
)